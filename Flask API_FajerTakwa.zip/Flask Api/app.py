from flask import Flask, render_template,request,redirect
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from wtforms import StringField,FloatField, IntegerField, SelectField, SubmitField
from wtforms.validators import DataRequired, InputRequired, NumberRange


import joblib
import sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import collections
import re
import pandas as pd
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier

app = Flask(__name__)
Bootstrap(app)
app.config["SECRET_KEY"] = "hard to guess string"

import collections
import re
def comptage(mail):
    listemots=["make","address","all","3d","our","over","remove","internet","order","mail","receive","will","people","report",
              "addresses","free","business","email","you","credit","your","font","000","money","hp","hpl","george","650","lab",
              "labs","telnet","857","data","415","85","technology","1999","parts","pm","direct","cs","meeting","original",
              "project","re","edu","table","conference"]
    listechars=[';','(','[','!','$','#']
   
    dic = {}
    text_split = re.split(r'\W+', mail)
    text_split_count = collections.Counter(text_split)
    for i in range(48):
        if listemots[i] in text_split_count.keys() : dic[listemots[i]] = float(100*text_split_count[listemots[i]]/len(text_split))
        else : dic[listemots[i]] = float(0)

    for i in range(6):
        dic[listechars[i]] = float(100*mail.count(listechars[i])/(len(mail)- mail.count(' ')))

    all_uppercase_sequence = re.findall(r"[A-Z]+", mail)
    sum_uppercase = 0

    for sequence in all_uppercase_sequence:
        sum_uppercase += len(sequence)

    if len(all_uppercase_sequence)!=0:
        dic['capital_run_length_average'] = int(sum_uppercase/len(all_uppercase_sequence))
        dic['capital_run_length_longest'] = int(len(max(all_uppercase_sequence, key=len)))
    else:
        dic['capital_run_length_average'] = 0
        dic['capital_run_length_longest'] = 0
    dic['capital_run_length_total'] = int(sum_uppercase)

    return dic

def fonctionfinal(mail):
    comptage(mail)
    res=comptage(mail)
    liste=[]
    for i,j in res.items():
        liste.append(j)
    listefinal=pd.DataFrame(liste) 
    listefinal=listefinal.T
    colonne=['word_freq_make', 'word_freq_address', 'word_freq_all', 'word_freq_3d', 'word_freq_our', 'word_freq_over', 'word_freq_remove', 'word_freq_internet', 'word_freq_order', 'word_freq_mail', 'word_freq_receive', 'word_freq_will', 'word_freq_people', 'word_freq_report', 'word_freq_addresses', 'word_freq_free', 'word_freq_business', 'word_freq_email', 'word_freq_you', 'word_freq_credit', 'word_freq_your', 'word_freq_font', 'word_freq_000', 'word_freq_money', 'word_freq_hp', 'word_freq_hpl', 'word_freq_george', 'word_freq_650', 'word_freq_lab', 'word_freq_labs', 'word_freq_telnet', 'word_freq_857', 'word_freq_data', 'word_freq_415', 'word_freq_85', 'word_freq_technology', 'word_freq_1999', 'word_freq_parts', 'word_freq_pm', 'word_freq_direct', 'word_freq_cs', 'word_freq_meeting', 'word_freq_original', 'word_freq_project', 'word_freq_re', 'word_freq_edu', 'word_freq_table', 'word_freq_conference', 'char_freq_;', 'char_freq_(', 'char_freq__', 'char_freq_!', 'char_freq_$', 'char_freq_#', 'capital_run_length_average', 'capital_run_length_longest', 'capital_run_length_total']
    listefinal.columns=colonne
    listefinal=listefinal.astype(float)
    listefinal["capital_run_length_average"]=listefinal["capital_run_length_average"].astype(int)
    listefinal["capital_run_length_longest"]=listefinal["capital_run_length_longest"].astype(int)
    listefinal["capital_run_length_total"]=listefinal["capital_run_length_total"].astype(int)
    return listefinal

## Forms
class EnterYourInfos(FlaskForm):
    email = StringField("Enter your email:",validators=[DataRequired()])
    submit = SubmitField("Submit")


@app.route("/predict",methods =["GET","POST"])
def prediction():
    form = EnterYourInfos()
    if request.method=="POST" and form.validate_on_submit():
        listefinal=fonctionfinal(form.email.data)
        #model=joblib.load("./model_rfc.joblib")
        #predictionfinal=model.predict(listefinal)[0]
        #session["result"]=predictionfinal
        #Reprendre tout du debut
        spam = pd.read_csv(r"C:/Users/Admin/OneDrive/Bureau/ESILV A4/S1/Python for Data Analysis/Project/spambase.data")
        y=spam['class']
        x=spam.drop(['class'],axis=1)

        from sklearn.linear_model import LogisticRegression
        lr=LogisticRegression(max_iter=10000)
        lr.fit(x,y)

        from sklearn.ensemble import RandomForestClassifier
        rfc=RandomForestClassifier()
        rfc.fit(x,y)

        import re
        regex = re.compile(r"\[|\]|<", re.IGNORECASE)
        x.columns = [regex.sub("_", col) if any(x in str(col) for x in set(('[', ']', '<'))) else col for col in x.columns.values]
        from xgboost import XGBClassifier
        xgb=XGBClassifier()
        xgb.fit(x,y)
        prediction=xgb.predict(listefinal)
        retour=''
        if prediction[0]==1:
            retour='The mail is a spam'
        if prediction[0]==0:
            retour='The mail is not a spam'
        return retour
    else :
        return render_template('prediction_form.html',form = form)
    #if request.method == "POST" and form.validate_on_submit():
     #   return redirect("/")
    #return render_template('prediction_form.html',form = form)

if __name__ == '__main__':
    #do something
    print( app.url_map)
    app.run(host ='127.0.0.1', port =5000,debug = True)